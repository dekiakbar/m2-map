<?php
/**
 * Copyright © nooby.dev All rights reserved.
 * See COPYING.txt for license details.
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Deki_FlashSale', __DIR__);

